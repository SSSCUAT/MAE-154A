%waypoint guidance
%D.Toohey

function  out = circleAimpoint(in)

tar_E = in(1);
tar_N = in(2);
pE = in(3);
pN = in(4);
way_num = in(5);
simTime = in(6);
tar_VE = in(7);
tar_VN = in(8);


    distWhaleE = pE- tar_E;
    distWhaleN = pN - tar_N;


whaleDistance = (distWhaleE^2+distWhaleN^2)^.5;
if simTime > 500
    out(1) = 0;
    out(2) = 0;
    out(3) = way_num;
    out(4) = 500;
    out(5) = 130;
    
else
    
    if whaleDistance > 3000  %search mode
        %if way_num < 5
        
        waypoints = [...
            1000 5000;...
            5000 10000; ...
            10000 11000;
            15000 12000];
        
        tempE = waypoints(way_num,1);
        tempN = waypoints(way_num,2);
        
        distE = pE- tempE;
        distN = pN - tempN;
        
        dist = (distE^2+distN^2)^.5;
        
        if dist < 200
            way_num = way_num + 1;
        end
        
        out(1) = tempE;
        out(2) = tempN;
        out(3) = way_num;
        out(4) = 1000;  %altitude command
        out(5) = 130;  % velocity command
        
    else
        
        followMode = 1;
        tarVmag = (tar_VE^2+tar_VN^2)^.5;
        if tarVmag < 80
           followMode = 0; 
        end
        
        if followMode == 1
            
            %for following
            followDistance = 1000;
            if tarVmag > 0
            vnorm = [tar_VE tar_VN]/tarVmag;
            aimpoint_E = tar_E -followDistance*vnorm(1);
            aimpoint_N = tar_N -followDistance*vnorm(2);
            else
            aimpoint_E = tar_E ;
            aimpoint_N = tar_N ;
                
            end
            
            vCommand =  tarVmag;
            if vCommand < 80
                vCommand =  80;
            end

            
        else
            %for circling
            
            circleRad = 2000;
            deltaAng = -0.6;
            
            delta_E = pE - tar_E;
            delta_N = pN - tar_N;
            uav_ang = atan2(delta_E,delta_N);
            tar_ang = uav_ang + deltaAng;
            
            aimpoint_E = tar_E + circleRad*sin(tar_ang);
            aimpoint_N = tar_N + circleRad*cos(tar_ang);
            
            if tarVmag > 80
                vCommand =  tarVmag*1.2;
            else
                vCommand =  80;
                
            end
            
        end
        
        out(1) = aimpoint_E;
        out(2) = aimpoint_N;
%        out(1) = circle_E;
%        out(2) = circle_N;
        out(3) = way_num;
        out(4) = 500;   % altitude command
        out(5) = vCommand;   %velocity command
    end
    
end

         
         
   
   
       
